import React from 'react'
import Test83 from './Test83'

function Test82() {
    return (
        <div>
            <Test83 />
        </div>
    )
}

export default Test82