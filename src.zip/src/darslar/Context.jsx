import React, {createContext} from 'react'
export const context=createContext();
