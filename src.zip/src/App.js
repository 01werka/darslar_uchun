// import Test08 from "./dars08/Test80";
// import Test10 from "./dars.10/Test10";
// import Test11 from "./uy ishi/Test11";
// import Test80 from "./dars08/Test80";
// import Uy1 from "./uy ishi2/Uy1"
import Test15 from "./dars 15/Test15";
import Routs from "./dars12/Routs";
import Test14 from "./dars14/Test14";
import Test16 from "./dars16/Test16";
import Uy3 from "./uy ishi 3/Uy3"
import State from './darslar/State'
import Effect from './darslar/Effect'
import Context from './darslar/Context'
import Context2 from "./darslar/Context2";
import { context } from './darslar/Context'
import Memo from './darslar/Memo'
import Reduser from "./darslar/Reduser"
import React, { useState, useReducer } from 'react'




function App() {
    const Personname = "Sherzod Tashpolatov";
    return (
      <div>
        {/* <Routs/>     */}
        {/* <Test16/> */}
        {/* <State/> */}
        {/* <Effect/> */}
        {/* <Context.Provider value={Personname}>
        <Context2 />
      </Context.Provider> */}
        {/* <Memo/> */}
        {/* <Reduser /> */}
      </div>
    )
  }



export default App;